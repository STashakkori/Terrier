# kGPT
Kotlin GPT runner asks the AI what its purpose is by default. Tailor from there. Thank you Aallam for the API

```
HttpClient: RESPONSE: 200 
METHOD: HttpMethod(value=POST)
FROM: https://api.openai.com/v1/chat/completions
COMMON HEADERS
-> access-control-allow-origin: *
-> cache-control: no-cache, must-revalidate
-> cf-cache-status: DYNAMIC
-> content-type: application/json
-> date: Thu, 26 Oct 2023 00:21:57 GMT
-> openai-model: gpt-3.5-turbo-0613
-> openai-version: 2020-10-01
-> server: cloudflare
-> strict-transport-security: max-age=15724800; includeSubDomains
Assistant: As an AI language model developed by OpenAI, my purpose is to assist and provide information
to users like you. I can help answer questions, complete tasks, provide explanations, and engage in
conversation on a wide range of topics.
```
